import java.io.*;
import java.util.*;

public class LinkedList {
    private ListNode head = null;
    private ListNode tail = null;
    private ListNode solution = null;
    private ArrayList<Integer> hashList = new ArrayList<>();

    /** The insert functions adds new nodes to the LinkedList
     *  Will check new nodes to add to see if they are a solution
     *
     */
    public void insert(Node value){
        ListNode new_node = new ListNode(value);
        new_node.next = null;
        if (new_node.isSolution){
            this.solution = new_node;
        }

        if(this.head == null){
            this.head = new_node;
            this.tail = this.head;
        }
        else if (!hashList.contains(new_node.value.hashCode())){
            ListNode last = this.tail;
            while(last.next != null){
                last = last.next;
            }
            last.next = new_node;
            this.tail = last;
        }
    }

    public void expandList(){
        ListNode last = this.head;
        ArrayList<Node[]> nodeList = new ArrayList<>();
        Integer tempHash;

        if(this.head == this.tail){
            Node[] initExpanded = last.value.expand();
            nodeList.add(initExpanded);
            this.hashList.add(initExpanded.hashCode());
        }

        while (last != null){
            tempHash = last.value.hashCode();
            if (!hashList.contains(tempHash)){
                Node[] expanded = last.value.expand();
                nodeList.add(expanded);
                this.hashList.add(tempHash);
            }
            last = last.next;
        }

        for (int i=0; i<nodeList.size();i++){
            for (int j=0; j<(nodeList.get(i)).length; j++){
                tempHash = nodeList.get(i)[j].hashCode();
                if (!hashList.contains(tempHash)) {
                    this.insert(nodeList.get(i)[j]);
                }
            }
        }
    }

    public boolean isSolved(){
        return this.solution!=null;
    }

    public Node getSolution(){return this.solution.value;}

    private class ListNode {
        public Node value;
        ListNode next;
        boolean isSolution;

        public ListNode(){};
        public ListNode(Node value){
            this.value = value;
            this.isSolution = value.isGoal();
        }
    }
}
